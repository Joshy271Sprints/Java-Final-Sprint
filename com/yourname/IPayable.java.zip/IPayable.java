package com.yourname;

public interface IPayable {
    double WeeklyPay();
}
